package Workers;

public abstract class WorkOrder extends Thread{

	@Override
	public abstract void run();

}
